<?php
if(!isset($_POST['submit']))
{
    //this page should not be accessed directly. Need to submit the form.
    echo "error; you need to submit the form!";
}
$name = $_POST['username'];
$visitor_email = $_POST['email'];
$number = $_POST['number'];
$message = $_POST['contact_message'];

//Validate first
if(empty($name)||empty($visitor_email)||empty($number))
{
    echo "Name, Email and number are mandatory!";
    exit;
}

$email_from = "hksharma201198@gmail.com";//<== put your email address here
$email_subject = "New form Submission";
$email_body = "You have recived a new massage from user $name .\n"
            "email address: $visitor_email . \n"
            "Here is the message : \n $message"
$to = "hksharma201198@gmail.com";//<== put your email address here
$headers = "From: $email_from \r\n";
$headers = "Reply-To: $visitor_email \r\n";
mail($to,$email_subject,$email_body,$headers);

?>
